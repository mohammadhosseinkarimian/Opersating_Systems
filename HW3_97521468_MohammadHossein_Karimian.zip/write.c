#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<errno.h>
#include<unistd.h>
#include<time.h>

#include "linked_list.h"

#define SHM_KEY 0x1234
#define SIZE_OF_BUFFER 2048


struct shm_seg {
   
   struct Node *head;
   int b_size;

   struct Node nodes[SIZE_OF_BUFFER];
   int number_of_nodes;
   int encrypt_value;

   int finished;
};

int main(int argc, char *argv[]) {

   srand(time(0));

   int shm_id;

   shm_id = shmget(SHM_KEY, sizeof(struct shm_seg), 0644|IPC_CREAT);
   if (shm_id == -1) {

      perror("Something is wromg with the shared memory");
      return 1;
   }

   struct shm_seg *shm_p;

   shm_p =  shmat(shm_id, NULL, 0);

   if (shm_p == (void *) -1) {

      perror("Something is wromg with the shared memory attach");
      return 1;
   }
   shm_p->head=NULL;
   shm_p->encrypt_value=7;

   shm_p->b_size=atoi(argv[1]);
   shm_p->number_of_nodes=0;
   shm_p->finished=0;
    
    int rc=0;
    char leaf_name[300];

    FILE *fp = popen("home/mhmd -type d -links 2", "r");
    while (fgets(leaf_name, 300 , fp) != NULL && rc < shm_p->b_size)
    {
        char enc_str[300];

        rc++;
        for(int i=0;i<strlen(leaf_name);i++)
        {
            enc_str[i]=leaf_name[i]+7;
        }
        //printf("Dir after encryption is : %s\n",enc_str);
        int random_number=rand();

        Add(&shm_p->head,random_number,enc_str,shm_p->number_of_nodes,shm_p->nodes);

        shm_p->number_of_nodes++;

        sleep(2);
    }

    for(int i=0;i<shm_p->number_of_nodes;i++)
    {
        printf("index of node: %d , value : %s , key : %d\n",i ,shm_p->nodes[i].value,shm_p->nodes[i].key);
    }

    shm_p->finished=1;
    printf("end of writer \n");

    sleep(10);

   if (shmctl(shm_id, IPC_RMID, 0) == -1) {
      perror("shmctl");
      return 1;
   }


    if (shmdt(shm_p) == -1) {
      perror("shmdt");
      return 1;
   }

   printf("Complete the writing\n");
   return 0;
}
