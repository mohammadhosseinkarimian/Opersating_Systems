#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>

#include "linked_list.h"

#define SHM_KEY 0x1234
#define SIZE_OF_BUFFER 2048

struct shm_seg {
struct Node *head;
int b_size;

struct Node nodes[SIZE_OF_BUFFER];
int number_of_nodes;
int encrypt_value;

int finished;
};

int main(int argc, char *argv[]) {
   struct shm_seg *shm_p;

   int shm_id;

   shm_id = shmget(SHM_KEY, sizeof(struct shm_seg), 0644|IPC_CREAT);

   if (shm_id == -1) {

      perror("Something went wrong with shared memory");
      return 1;
   }

   shm_p = (struct shm_seg *)shmat(shm_id, NULL, 0);

   if (shm_p == (void *) -1) {

      perror("Something went wrong with shared memory attach");
      return 1;
   }

    while(shm_p->finished != 1)
   {
    int enc_v=shm_p->encrypt_value;
    int rc=shm_p->number_of_nodes;

       for(int i=0;i<rc;i++)
       {
           printf("values[%d] after decryption: \n",i);
           char* str=shm_p->nodes[i].value;
           for(int j=0;j<strlen(str);j++)
           {
               printf("%c",str[j]-enc_v);
           }
       }
       sleep(2);
   }
    //final leaf
    int enc_val=shm_p->encrypt_value;
    int rc=shm_p->number_of_nodes;

       for(int i=0;i<rc;i++)
       {
           printf("values[%d] after decryption: \n",i);
           char* str=shm_p->nodes[i].value;
           
           for(int j=0;j<strlen(str);j++)
           {
               printf("%c",str[j]-enc_val);
           }
       }

    return 0;
}