#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    
    int fd[2];
    pipe(fd);
    pid_t childpid;
    childpid = fork();

    if(childpid==0)
    {
        char *first[4];
        first[0] = "ps";
        first[1] = "-A";
        first[2] = "-T";
        first[3] =NULL;
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        execvp("ps",first);
        exit(0);
    }
    else
    {
        char *second[3];

        second[0] = "grep";
        second[1] = "chrome";
        second[2] =NULL;
        close(fd[1]);
        dup2(fd[0], STDIN_FILENO);
        execvp("grep",second);
    }
    return 0;
}
