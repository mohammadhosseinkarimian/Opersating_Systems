#ifndef SM_LINKED_LIST_H
#define SM_LINKED_LIST_H
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#define MAXIMUM 2048
struct Node
{
    int key;
    char value[MAXIMUM];
    struct Node* next;
};

void Add(struct Node** head,int key,char values[],int ind,struct Node node_list[])
{
    struct Node* current = (struct Node*)malloc(sizeof(struct Node));
    current->next = *head;
    current->key = key;
    strcpy(current->value, values);
    *head = current;
    node_list[ind] = *current;
}
#endif
