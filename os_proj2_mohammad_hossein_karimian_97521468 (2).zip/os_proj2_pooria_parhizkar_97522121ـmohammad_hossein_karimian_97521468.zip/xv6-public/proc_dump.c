#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char const *argv[])
{
    int a,b;
    int x = fork();
//child
    if (x == 0)
    {
	waitx(&a,&b);
        int i;
        malloc(987654);
        while (i<9999999)
        {
           // i = 1379 * 21;
            //i = i * 6;
	    i++;
        }
	exit();
    }
//parent
    else
    {
        int y = fork();
        if (y == 0)
        {
	    waitx(&a,&b);
            int j;
            malloc(123456);
            while (j<90000)
            {
                //j = 741 * 369;
                //j *=9;
		j++;
            }
            exit();
        }
        else
        {
	    set_priority(y,20);
	    set_priority(x,80);
            sleep(10);
            //call our syscall
            proc_dump();
            //kill child to have not zombie process
            kill(x);
            kill(y);
            exit();
        }
    }
}

